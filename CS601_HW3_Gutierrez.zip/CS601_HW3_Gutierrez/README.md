MET CS601:  Module 3 Assignment - JOHN GUTIERREZ
PORTFOLIO


DEPLOYMENT AND LINK
The PORTFOLIO website has been deployed in Blue Host:

https://bks.boo.mybluehost.me/portfolioHW3/


OVERVIEW
This portfolio presents the school work of John Gutierrez, a Web Application Development
student at BU. It includes four interactive projects, links to professional profiles, 
and a contact section. The website uses HTML and CSS, with some JavaScript to dynamically 
display data.


FEATURES
Header: Includes the portfolio's logo, name, description, and a navigation menu with links to different sections of the website.
About Me: Personal information along with links to LinkedIn, GitHub, and a course syllabus.
Projects Section: Displays a grid of John’s projects with clickable project titles and images.
Footer: Contains copyright information and links to social media profiles (LinkedIn, GitHub, Twitter, Facebook, Instagram, Telegram).
Responsive Design: The layout adjusts for mobile, tablet, and desktop views using CSS media queries.
Hover Effects: Interactive hover effects on links and project titles.


STRUCTURE
The project consists of the following main files:

1. index.html – The main HTML file for the portfolio.
2. css/main.css – The stylesheet that defines the look and layout of the portfolio.
3. images/ – Folder containing images for the logo, social media icons, project images, etc.


TECHNOLOGIES
HTML/CSS: Structure and styling.
JavaScript: Manages drag-and-drop and fetches data.
JSON: Stores items' data.

HTML Code
The HTML structure is as follows:

1. Header Section: Contains a logo, name, description, and a navigation bar with links to various sections of the page.
2. Main Section:
3. Sidebar: Displays an image of John and provides links to professional profiles and other resources.
4. Projects Section: A grid layout showcasing John's web development projects with clickable links to more details.
5. Footer Section: Contains copyright information and social media links.

CSS Code
The CSS handles layout, styling, and responsiveness:

General Styles
Reset: All margin and padding values are set to zero to create a consistent base.
Body: The body of the page uses the Arial font-family, a light background color, and a justified text alignment.

Header Styles
The header has a dark background with white text. The logo is styled to be circular, and the navigation menu links change color when hovered.

Sidebar Styles
The sidebar is positioned with a white background, a shadow, and rounded corners. It contains links styled with custom hover effects and arrows.

Projects Grid Layout
The projects section is displayed using a CSS grid, with each project placed inside a div that includes an image and a description. Hover effects are added to the project titles.

Footer Styles
The footer includes social media links with icons. The year in the copyright notice is dynamically set using JavaScript.

Responsive Design
The site is responsive, ensuring a smooth experience across all devices:

Mobile (Max-width: 768px): The layout switches to a single column for both the sidebar and projects.
Medium Screens (Min-width: 768px, Max-width: 1024px): The project grid is displayed in two columns.
Large Screens (Min-width: 1200px): The project grid is displayed in three columns, with the last project centered.

